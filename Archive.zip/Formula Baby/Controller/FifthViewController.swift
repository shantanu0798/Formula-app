//
//  FifthViewController.swift
//  Formula Baby
//
//  Created by Prashant Bhatnagar on 15/07/18.
//  Copyright © 2018 Team NASK. All rights reserved.
//

//import Foundation
import UIKit
import Charts

class FifthViewController: UIViewController {

    @IBOutlet weak var txtTextBox: UITextField!
    @IBOutlet weak var chtChart: LineChartView!
    
    var numbers : [Double] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //
    }

override func didReceiveMemoryWarning() {
    super.didReceiveMemoryWarning()
    // Dispose of any resources that can be recreated.
}
    
    
    @IBAction func btnbutton(_ sender: Any) {
        
        let input = Double(txtTextBox.text!)
        numbers.append(input!)
        UserDefaults.standard.set(numbers, forKey: "")
        
        updateGraph()
        
    }
    
    func updateGraph()
    {
        var LineChartEntry = [ChartDataEntry]()
        
        for i in 0..<numbers.count
        {
            let value = ChartDataEntry(x: Double(i) , y:numbers[i])
            LineChartEntry.append(value)
        }
        
        let line1 = LineChartDataSet(values: LineChartEntry , label: "Number")
        line1.colors = [NSUIColor.blue]
        
        let data = LineChartData()
        data.addDataSet(line1)
        chtChart.data = data
        chtChart.chartDescription?.text = "My awesome chart"

        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
    }
    
    
}
